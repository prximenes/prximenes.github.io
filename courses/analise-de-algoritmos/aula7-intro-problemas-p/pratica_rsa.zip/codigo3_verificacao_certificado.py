#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prática de Laboratório: Análise de Algoritmos • UNICAP
Missão 3: Encontrar vs. Verificar (A Facilidade de Checar um Certificado)
Prof. Pedro Ximenes
"""

import time

def verificar_certificado(n, candidato_p):
    """
    Verifica se candidato_p é de fato um divisor não-trivial de n.
    Custo: Uma única divisão inteira (Tempo Polinomial O(log² n) nos bits).
    """
    t0 = time.perf_counter()
    eh_valido = (1 < candidato_p < n) and (n % candidato_p == 0)
    q = (n // candidato_p) if eh_valido else None
    t_gasto = time.perf_counter() - t0
    return eh_valido, q, t_gasto

def main():
    print("=" * 82)
    print("  MISSÃO 3: ENCONTRAR (DIFÍCIL) VS. VERIFICAR (FÁCIL)")
    print("  A ponte entre Problemas de Busca e a Classe NP (Verificadores Polinomiais)")
    print("=" * 82)
    print()

    # Um número RSA de 70 bits onde a busca demoraria dias/semanas
    n = 1180591625390335725871
    print(f"Número RSA Público: n = {n} (~70 bits)")
    print("Suponha que alguém afirme ter quebrado a chave e entregue um 'Certificado'...")
    print("-" * 82)

    testes = [
        ("Certificado A (Correto)", 34359738421),
        ("Certificado B (Chute Falso)", 34359738423),
        ("Certificado C (Outro Falso)", 12345678901)
    ]

    for label, cand in testes:
        valido, outro_fator, tempo = verificar_certificado(n, cand)
        status = f"✅ VÁLIDO! (outro fator = {outro_fator})" if valido else "❌ INVÁLIDO (não divide n)"
        print(f"{label:<30} | Candidato p = {cand:<14} | {status:<32} | Tempo: {tempo*1e6:.2f} µs")

    print("-" * 82)
    print()
    print("💡 CONCLUSÃO PEDAGÓGICA (Slides 22-25 e introdução a NP):")
    print(" 1. ENCONTRAR os fatores levou timeout de busca exaustiva (milhões de divisões).")
    print(" 2. VERIFICAR o certificado levou UMA ÚNICA DIVISÃO (~0.5 microssegundos).")
    print(" 3. Essa é a essência do que veremos nas próximas aulas:")
    print("    - Problemas onde encontrar a resposta pode ser exponencial,")
    print("    - mas verificar uma solução proposta é SEMPRE Polinomial (Classe NP).")
    print("=" * 82)

if __name__ == "__main__":
    main()
